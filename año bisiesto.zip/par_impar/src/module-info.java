/**
 * 
 */
/**
 * @author Jason
 *
 */
module par_impar {
}